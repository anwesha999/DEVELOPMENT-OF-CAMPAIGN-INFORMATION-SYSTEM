<?php session_start(); 
if(isset($_POST['sub'])) {
$type = isset($_POST['type']) ? $_POST['type']:'';}
	$status = $_POST['status'];
		
		$errors = [];
		}
		if(empty($type)) {
			$errors['type'] = 'Please fill the ';
		}
		
		if(empty($status)) {
			$errors['status`'] = 'Please fill the status';
		}
		
		if(!empty($errors)) {
			$_SESSION['errors'] = $errors;
			header("Location:../signup.php");
			die;
		}
		
		$link = @mysqli_connect('localhost','root','','login');
		
		if(!$link) {
			die('Connection Error '.mysqli_connect_errno().'-'.mysqli_connect_error());
		}
		
		$query = "insert into ldata (name,email,password,gender,mobile,dob,status) value('".
		$name."','".$email."','".$password."','".$gender."','".$mobile."','".$dob."','".$status."')";
		
		$result = mysqli_query($link,$query);
		
		if($result) {
			$_SESSION['msg'] = '<p><b>Congratulations!!!</b> You have successfully registered with us.</p>';
		}else {
			$_SESSION['msg'] = '<p><b>Sorry!!!</b> Some problem occured. Please <a href="../signup.php">Try again</a></p>';
		}
	}
	header("Location:../signup-status.php");
?>